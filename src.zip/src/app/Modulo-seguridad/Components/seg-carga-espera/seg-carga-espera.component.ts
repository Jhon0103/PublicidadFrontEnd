import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seg-carga-espera',
  templateUrl: './seg-carga-espera.component.html',
  styleUrls: ['./seg-carga-espera.component.css']
})
export class SEGCargaEsperaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
