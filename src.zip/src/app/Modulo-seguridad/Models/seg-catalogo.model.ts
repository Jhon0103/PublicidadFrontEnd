export class dniDTO{
    success?:string
    message?:string
    dni?:string
    nombres?:string
    apellidoPaterno?:string
    apellidoMaterno?:string
}

export class rucDTO{
    success?:string
    message?:string
    ruc?:string
    razonSocial?:string
    nombreComercial?:string
    estado?:string
    condicion?:string
}