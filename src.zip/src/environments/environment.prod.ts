export const environment = {
  production: true,
  
  //API DE SEGURIDAD
  //url_api : 'https://pay-met.pe:8098/api/', //QAS
  url_api : 'https://pay-met.pe:8092/api/', //PRODUCCION

  //API MAESTRAS
  //url_api_maestras : 'https://pay-met.pe:8098/api/' //QAS
  url_api_maestras : 'https://pay-met.pe:8092/api/' //PRODUCCION
};
