export class solicitudDTO {
  idSolicitud: number;
  proyecto: string;
  descripcion: string;
  idTipoSolicitud: number;
  fechaEstimadaUsuario?: string;
  fechaEstimadaEntrega?: string;
  idEstadoSolicitud: number;
  comentarios: string;
  idUsuario: number;

  tipoSolicitud: string;
  estado: string;
  fechaCrea?: string;
  usuario : string;

  constructor() {
    this.idSolicitud = 0;
    this.proyecto = '';
    this.descripcion = '';
    this.idTipoSolicitud = 0;
    this.idEstadoSolicitud = 0;
    this.comentarios = '';
    this.idUsuario = 0;

    // campos del join
    this.tipoSolicitud = '';
    this.estado = '';
    this.usuario = '';
  }
}
export class tipoSolicitud{
  idTipoSolicitud! : number;
  tipoSolicitud! : string;
  descripcion! : string;
}

export class listaEstado{
  idEstadoSolicitud! : number;
  estado! : string;
}