
export const environment = {
  production: true,

  url_api : 'http://localhost:18548/api/', //LOCAL
  url_api_maestras : 'http://localhost:2369/api/' //LOCAL

};
